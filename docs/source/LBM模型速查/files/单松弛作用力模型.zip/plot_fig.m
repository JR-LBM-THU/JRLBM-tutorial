% x=-0.5:1:n-1.5;% 修改的地方
% xx=0:0.1:n-2;
% clors = ['r','g','b','c','k'];
% if mod(kk,floor(mstep/10))==0
%     figure(1)
%     clf
%     scatter(x,v(:,floor(m/2)),'DisplayName', 'LBM','MarkerEdgeColor','b');
%     hold on;
%     U_plot=Fy/2/(rhoo*nu).*xx*dx.*(n-2-xx)*dx; % 修改的地方
% %     绘制解析解的点，不要线,不显示DisplayName
%     plot(xx,U_plot,'-','DisplayName','ANA','LineWidth',1.5,'Color', 'b');
%     legend('show','Location','northwest');
%     xlabel('y');
%     ylabel('velocity');
%     xlim([-1,n-1]);
%     disp((max(max(v))-max(U_plot))/max(U_plot))
% end


if mod(kk,frequency)==0
    velocity = (u.^2 + v.^2).^0.5;
    velocity(shape==1) = nan;
    figure(2)
    %设置图的比例
    set(gcf,'unit','centimeters','position',[30 0 20 18]);
    x = 0.5:1:n-0.5;
    y = 0.5:1:m-0.5;
    [X, Y] = meshgrid(x,y);
    gca = pcolor(X, Y, velocity');
    %用rainbow
    colormap(jet);
    colorbar;
    set(gca, 'LineStyle','none');
    xlabel('x');
    ylabel('y');
    title(['velocity at step ',num2str(kk)]);
    %设置颜色条的刻度0.9到1.1
    % clim([0 max(max(velocity))]);
    disp(max(max(velocity)));
end
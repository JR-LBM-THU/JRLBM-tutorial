% 代码讲解见B站：JR同学教LBM-THU
% 文档见网站：https://jrlbm-tutorial.readthedocs.io/

% 此文件使用D2Q9求解任意复杂多孔介质流动，并将泊肃叶流动的模拟结果进行了对比
% 边界采用半反弹边界，作用力作为驱动力，不再需要施加压力边界
clear
clc
% 定义一些常量
dx = 1;
dt = dx^2;
cc = dx/dt;
cs2 = cc^2/3;
length = 100;
width = 100;
n=length/dx; %泊肃叶流动+2
m=width/dx;
mstep=1000/dt;
frequency = 200;
rhoo = 1.00;
nu = 0.1;
tau = 3*dt*nu/dx^2 + 0.5;
omega = 1.0/tau;
% 定义变量
rho = ones(n,m);
f = zeros(9,n,m);
feq = zeros(9,n,m);
u = zeros(n,m);
v = zeros(n,m);
u_ = zeros(n,m);
v_ = zeros(n,m);
velocity = zeros(n,m);


%define the weight coefficient.
w=[1/9;1/9;1/9;1/9;1/36;1/36;1/36;1/36;4/9];
e = [1,0 ; 0,1 ; -1,0 ; 0,-1 ; 1,1 ; -1,1 ; -1,-1 ; 1,-1 ; 0,0]*cc;

Fx = 0;
Fy = 0.00001;

% initialize the distribution function.
for k=1:1:9
    f(k,:,:)=feq_D2Q9(k,rho,u,v,w,e,cs2);
end

shape = zeros(n, m);
% shape(rand(n,m)<0.3) = 1;
% 修改成你自己的几何
% for i = 1:1:n
%     for j = 1:1:m
%         if (((i - 0.5)* dx - length/2)^2 + ((j-0.5)*dx - width/2)^2)^0.5 <= 10
%             shape(i + 1,j + 1) = 1;
%         end
%     end
% end
shape(20:80,80) = 1;
shape(50,20:80) = 1;
shape(20:50,20) = 1;
shape(20,20:30) = 1;
% 计算泊肃叶流动
% shape(1,:) = 1;
% shape(end,:) = 1;

index = zeros(8, n, m);
for i = 1:1:8
    index(i,shape==0 & circshift(shape,[round(e(i,1)/cc),round(e(i,2)/cc)]) == 1) = 1;
end

%main cycle
tic;
for kk=1:1:mstep
    % collision
    for k =1:1:9
%         % Guo et al. (2002)
%         e_u = e(k,1)*u + e(k,2)*v;
%         S_i = ( ((e(k,1)-u)/cs2 + (e_u*e(k,1))/cs2/cs2).*Fx + ...
%                             ( (e(k,2)-v)/cs2 + (e_u*e(k,2))/cs2/cs2 ).*Fy );
%         feq(k,:,:)=feq_D2Q9(k,rho,u,v,w,e,cs2);
%         f(k,:,:) = squeeze(omega * feq(k,:,:) + (1-omega)*f(k,:,:)) + ...
%             dt*w(k)*(1-0.5/tau).*S_i;

%         % He et al. (1998)
%         feq(k,:,:)=feq_D2Q9(k,rho,u,v,w,e,cs2);
%         S_i = ((e(k,1)-u).*Fx + (e(k,2)-v).*Fy).*squeeze(feq(k,:,:))./rho/cs2;
%         f(k,:,:) = squeeze(omega * feq(k,:,:) + (1-omega)*f(k,:,:)) + ...
%             dt*(1-0.5/tau).*S_i;

%         % Exact Difference Method (EDM)
%         feq(k,:,:) = feq_D2Q9(k,rho,u_,v_,w,e,cs2);
%         feq_ = reshape(feq_D2Q9( k, rho, u_+Fx*dt./rho, v_+Fy*dt./rho, w, e, cs2), 1, n, m);
%         f(k,:,:) = omega * feq(k,:,:) + (1-omega)*f(k,:,:) + feq_ - feq(k,:,:);

        % Shan and Chen (1993)
        feq(k,:,:) = feq_D2Q9( k, rho, u + tau*Fx./rho, v + tau*Fy./rho, w, e, cs2);
        f(k,:,:) = omega * feq(k,:,:) + (1-omega)*f(k,:,:);
    end

    f_old = f;
    %streaming
    evolution

    % 边界处理
    inv_direction = [3,4,1,2,7,8,5,6];
    for i = 1:1:8
        f(i,index(i,:,:) == 1) = f_old(inv_direction(i),index(i,:,:) == 1);
    end

    % 计算宏观量
    rho = squeeze(sum(f,1));
    usum=zeros(n,m);
    vsum=zeros(n,m);
    for k=1:1:9
        usum = usum + squeeze(f(k,:,:)) * e(k,1);
        vsum = vsum + squeeze(f(k,:,:)) * e(k,2);
    end
%     u = (usum + dt * Fx / 2) ./ rho;
%     v = (vsum + dt * Fy / 2) ./ rho;
%     % EDM需要
%     u_ = usum ./ rho;
%     v_ = vsum ./ rho;

    % EDM、Shan and Chen需要
    u = usum ./ rho;
    v = vsum ./ rho;

    plot_fig
end
toc;
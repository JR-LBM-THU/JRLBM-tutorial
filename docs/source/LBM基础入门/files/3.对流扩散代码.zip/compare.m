clear
clc
figure(1)
load('D2Q5_u=0.05.mat');
plot(0:1:Lx,T(:,1),'LineStyle','-','LineWidth',2,'Color','b','DisplayName','D2Q5');
hold on
load('D2Q9_u=0.05.mat');
scatter(0:1:Lx,T(:,1),'o','LineWidth',2,'MarkerEdgeColor','r','DisplayName','D2Q9');
legend()
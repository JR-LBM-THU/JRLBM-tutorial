% LBM- 1-D1Q3, advection-diffusion equation D1Q3
clear
clc
u=0.05;
L = 200;
m=201;
dx=L/(m-1);
dt = 1;
c=dx/dt;
cs2 = c^2/3;
w=[1/6,1/6,4/6]';
e = [1,-1,0]*c;
x=0:dx:L;
phi=zeros(1,m);
phi(10:30)=1;
alpha=0.05;
omega=1/(3.*alpha*dt/dx^2+0.5);
tw_left=0.0;
tw_right=0.0;
nstep=1200/dt;
f = w*phi;
colors = winter(nstep);

for k1=0:nstep
    if mod(k1,nstep/5)==0
        figure(1)
        % 使用颜色映射中的某一颜色，使用 k1 来映射颜色
        color_index = mod(k1, size(colors, 1)) + 1;
        plot(x, phi, 'DisplayName', ['Time = ', num2str(k1*dt)], 'Color', colors(color_index, :),...
            'LineWidth', 1.5)
        hold on
        legend('-DynamicLegend')
        xlabel('x')
        ylabel('\phi')
        drawnow
        ylim([-0.1,1.1]);
    end

    % collision
    for i = 1:1:3
        feq = w(i)*phi*(1+ e(i)*u/cs2);
        f(i,:) = (1-omega)*f(i,:) + omega*feq;
    end
    % Streaming:
    for i = 1:2
        f(i,:) = circshift(f(i,:), round(e(i)/c));
    end
    %Boundary condition:
    f(1,1)=tw_left-f(2,1)-f(3,1);
    f(2,m)=tw_right-f(1,m)-f(3,m);

    % Macroscopic:
    phi = sum(f,1);
end
% LBM- 2-D2Q5, advection-diffusion equation, note that c2=1/3, w0=2/6, others 1/6
clear
u=0.05;
Lx=200;Ly=50;
dx = 1;
dt = 1;
c = dx/dt;
cs2 = c^2/3;
m = Lx/dx+1;
n = Ly/dx+1;
w = [1/6, 1/6, 1/6, 1/6, 2/6];
e = [[1,0];[0,1];[-1,0];[0,-1];[0,0]]*c;
T=zeros(m,n);
f = zeros(5, m, n);
alpha=0.1;
omega=1/(0.5+3*alpha*dt/(dx^2));
twall=1.0;


nstep=2000/dt;

% initial condition
for k = 1:5
    f(k, :, :) = w(k).*T*(1+ e(k)*u/cs2);
end
tic;
%Collision:
for kk=1:nstep
    % collision
    for k = 1:1:5
        feq = w(k)*T*(1+ e(k)*u/cs2);
        f(k,:,:) = (1-omega)*squeeze(f(k,:,:)) + omega*feq;
    end
    % Streaming:
    for k = 1:1:5
        f(k,:,:) = circshift(squeeze(f(k,:,:)), round(e(k,:)/c));
    end

    %Boundary condition:
    f(2,:,1) = f(2,:,2);
    f(1,1,:) = twall - (f(2,1,:) + f(3,1,:) + f(4,1,:) + f(5,1,:));
    f(3,m,:) = 0 - (f(1,m,:) + f(2,m,:) + f(4,m,:) + f(5,m,:));
    f(4,:,n) = 0 - (f(1,:,n) + f(2,:,n) + f(3,:,n) + f(5,:,n));

    % calculate T
    T = squeeze(sum(f, 1));

end
toc;
figure(2)
%设置图的比例
set(gcf,'unit','centimeters','position',[5 5 45 15]);
x = 0:1:Lx;
y = 0:1:Ly;
[X, Y] = meshgrid(x,y);
gca = pcolor(X, Y, T');
%用rainbow
shading interp;
colormap('hot');
% 设置色阶范围
clim([0,1.0]);
colorbar;
set(gca, 'LineStyle','none');
xlabel('x');
ylabel('y');
title(['T at step ',num2str(kk)]);
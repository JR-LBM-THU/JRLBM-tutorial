figure(1)
dx = [ 0.5, 1, 2];
epsilon = [ 0.0010, 0.0041, 0.0168];
scatter(dx,epsilon,50,'MarkerFaceColor','none','MarkerEdgeColor','b', ...
    'DisplayName','data')
% 设置 y 轴为对数刻度
set(gca, 'YScale', 'log')
% 设置 x 轴为对数刻度
set(gca, 'XScale', 'log')

% 对数据进行log-log拟合
p = polyfit(log(dx),log(epsilon),1);
% 计算拟合的直线
y = polyval(p,log(dx));
hold on
plot(dx,exp(y),'b','LineWidth',1.5,'LineStyle','--', ...
    'DisplayName',['y = ',num2str(exp(p(2))),'x^{',num2str(p(1)),'}'])
legend('show')
xlabel('\delta_x')
ylabel('epsilon')
title('log-log plot of epsilon vs dx')
hold off

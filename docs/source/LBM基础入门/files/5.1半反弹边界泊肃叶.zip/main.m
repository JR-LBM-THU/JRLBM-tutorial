% 代码讲解见B站：JR同学教LBM-THU
% 文档见网站：https://jrlbm-tutorial.readthedocs.io/

% 此文件使用D2Q9求解泊肃叶流动，并将计算结果与理论结果进行了比较，
% 边界采用半反弹边界（相较于全反弹，所有的n+1换成了n）
clear
clc
% 定义一些常量
dx = 1;
dt = 1;
cc = dx/dt;
cs2 = cc^2/3;
n=20/dx;
m=50/dx;
dp = 0.001;
mstep=10000/dt;
rhoo = 1.00;
nu = 0.1;
tau = 3*dt*nu/dx^2 + 0.5;
omega = 1.0/tau;
% 定义变量
rho = ones(n,m+1)*rhoo;
f = zeros(9,n,m + 1);
feq = zeros(9,n,m + 1);
u = zeros(n,m+1);
v = zeros(n,m+1);
velocity = zeros(n,m+1);


%define the weight coefficient.
w=[1/9;1/9;1/9;1/9;1/36;1/36;1/36;1/36;4/9];
e = [1,0 ; 0,1 ; -1,0 ; 0,-1 ; 1,1 ; -1,1 ; -1,-1 ; 1,-1 ; 0,0]*cc;


% initialize the distribution function.
for k=1:1:9
    f(k,:,:)=feq_D2Q9(k,rho,u,v,w,e,cs2);
end

%main cycle
tic;
for kk=1:1:mstep
    % collision
    for k =1:1:9
        feq(k,:,:)=feq_D2Q9(k,rho,u,v,w,e,cs2);
        f(k,:,:) = omega*feq(k,:,:)+(1-omega)*f(k,:,:);
    end

    f_old = f;% 修改的地方
    %streaming
    evolution

    %left boundary u=0,v=0 全反弹
    f(1,1,:) = f_old(3,1,:);% 修改的地方
    f(5,1,:) = f_old(7,1,:);% 修改的地方
    f(8,1,:) = f_old(6,1,:);% 修改的地方
    %right boundary u=0,v=0 全反弹
    f(3,end,:) = f_old(1,end,:);% 修改的地方
    f(7,end,:) = f_old(5,end,:);% 修改的地方
    f(6,end,:) = f_old(8,end,:);% 修改的地方

    % 计算宏观量
    rho = squeeze(sum(f,1));
    usum=zeros(n,m+1);
    vsum=zeros(n,m+1);
    for k=1:1:9
        usum = usum + squeeze(f(k,:,:)) * e(k,1);
        vsum = vsum + squeeze(f(k,:,:)) * e(k,2);
    end
    u = usum ./ rho;
    v = vsum ./ rho;

    %   Move at y=m+1， 非平衡态边界条件
    rho(:,end) = rhoo;
    u(:,end) = u(:,end-1);
    v(:,end) = v(:,end-1);
    Feq=ones(9,n,2);
    for k=1:1:9
        Feq(k,:,1) = feq_D2Q9(k,rho(:,end),u(:,end),v(:,end),w,e,cs2);
        Feq(k,:,2) = feq_D2Q9(k,rho(:,end-1),u(:,end-1),v(:,end-1),w,e,cs2);
    end
    f(:,:,end)=Feq(:,:,1)+f(:,:,end-1)-Feq(:,:,2);

    %   Move at y=1， 非平衡态边界条件
    rho(:,1) = rhoo+dp/cs2;
    u(:,1) = u(:,2);
    v(:,1) = v(:,2);
    Feq=ones(9,n,2);
    for k=1:1:9
        Feq(k,:,1) = feq_D2Q9(k,rho(:,1),u(:,1),v(:,1),w,e,cs2);
        Feq(k,:,2) = feq_D2Q9(k,rho(:,2),u(:,2),v(:,2),w,e,cs2);
    end
    f(:,:,1)=Feq(:,:,1)+f(:,:,2)-Feq(:,:,2);

    plot_fig
end
toc;
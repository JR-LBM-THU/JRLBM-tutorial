x=0.5:1:n-0.5;% 修改的地方
xx=0:0.1:n;
clors = ['r','g','b','c','k'];
if mod(kk,floor(mstep/10))==0
    figure(1)
    clf
    scatter(x,v(:,floor(m/2)),'DisplayName', 'LBM','MarkerEdgeColor','b');
    hold on;
    U_plot=dp/2/(m*dx*rhoo*nu).*xx*dx.*(n-xx)*dx;
%     绘制解析解的点，不要线,不显示DisplayName
    plot(xx,U_plot,'-','DisplayName','ANA','LineWidth',1.5,'Color', 'b');
    legend('show','Location','northwest');
    xlabel('y');
    ylabel('velocity');
    xlim([0,n]);
    disp((max(max(v))-max(U_plot))/max(U_plot))
end

% if mod(kk,floor(mstep/10))==0
%     figure(2)
%     %设置图的比例
%     set(gcf,'unit','centimeters','position',[0 0 10 10]);
%     x = 0:1:n;
%     y = 0:1:m;
%     [X, Y] = meshgrid(x,y);
%     gca = pcolor(X, Y, u');
%     %用rainbow
%     shading interp;
%     colormap(jet);
%     colorbar;
%     set(gca, 'LineStyle','none');
%     xlabel('x');
%     ylabel('y');
%     title(['ux at t = ',num2str(kk*dt)]);
% end
% 此文件使用D2Q9求解平板库埃特流动，并将计算结果与理论结果进行了比较
clear
clc
% 定义一些常量
dx = 1;
dt = 1;
cc = dx/dt;
cs2 = cc^2/3;
n=10/dx;
m=50/dx;
mstep=2000/dt;
uo = 0.1;
rhoo = 1.00;
nu = 0.1;
tau = 3*dt*nu/dx^2 + 0.5;
omega = 1.0/tau;
% 定义变量
rho = ones(n+1,m+1)*rhoo;
f = zeros(9,n + 1,m + 1);
feq = zeros(9,n + 1,m + 1);
u = zeros(n+1,m+1);
v = zeros(n+1,m+1);
velocity = zeros(n+1,m+1);


%define the weight coefficient.
w=[1/9;1/9;1/9;1/9;1/36;1/36;1/36;1/36;4/9];
e = [1,0 ; 0,1 ; -1,0 ; 0,-1 ; 1,1 ; -1,1 ; -1,-1 ; 1,-1 ; 0,0]*cc;


% initialize the distribution function.
for k=1:1:9
    f(k,:,:)=feq_D2Q9(k,rho,u,v,w,e,cs2);
end


%main cycle
tic;
for kk=1:1:mstep
    % collision
    for k =1:1:9
        feq(k,:,:)=feq_D2Q9(k,rho,u,v,w,e,cs2);
        f(k,:,:) = omega*feq(k,:,:)+(1-omega)*f(k,:,:);
    end

    %streaming
    evolution

    %bottom boundary u=0,v=0 全反弹
    f(2,:,1) = f(4,:,1);
    f(5,:,1) = f(7,:,1);
    f(6,:,1) = f(8,:,1);
%     % top boundary u=u0 Zou-He格式
%     rhow = f(9,:,end) + f(1,:,end) + f(3,:,end) + 2*(f(2,:,end)+f(5,:,end)+f(6,:,end));
%     f(4,:,end) = f(2,:,end);
%     f(7,:,end) = f(5,:,end) - rhow * uo /2/cc + (f(1,:,end) - f(3,:,end))/2;
%     f(8,:,end) = f(6,:,end) + rhow * uo /2/cc - (f(1,:,end) - f(3,:,end))/2;

    % 计算宏观量
    rho = squeeze(sum(f,1));
    usum=zeros(n+1,m+1);
    vsum=zeros(n+1,m+1);
    for k=1:1:9
        usum = usum + squeeze(f(k,:,:)) * e(k,1);
        vsum = vsum + squeeze(f(k,:,:)) * e(k,2);
    end
    u = usum ./ rho;
    v = vsum ./ rho;

    %   Move at y=m+1， 非平衡态边界条件
    rho(:,m+1) = rho(:,m);
    u(:,m+1) = uo;
    v(:,m+1) = 0;
    Feq=ones(9,n+1,2);
    for k=1:1:9
        Feq(k,:,1) = feq_D2Q9(k,rho(:,m+1),u(:,m+1),v(:,m+1),w,e,cs2);
        Feq(k,:,2) = feq_D2Q9(k,rho(:,m),u(:,m),v(:,m),w,e,cs2);
    end
    f(:,:,m+1)=Feq(:,:,1)+f(:,:,m)-Feq(:,:,2);

    plot_fig
end
toc;
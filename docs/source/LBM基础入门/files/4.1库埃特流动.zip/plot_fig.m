y=0:1:m;
clors = ['r','g','b','c','k'];
if mod(kk,floor(mstep/5))==0
    figure(1)
    scatter(y,u(floor(n/2),:),'DisplayName', ['LBM:t=',num2str(kk*dt)],'MarkerEdgeColor',...
        clors(kk/floor(mstep/5)));
    hold on;
    U_plot=uo.*y*dx/m/dx.*ones(1,m+1);
    for N = 1:1:100
        U_plot=U_plot-2*uo/pi/N.*exp(-N^2*pi^2*nu*kk*dt/(m*dx)^2).*sin(N*pi*(1-y*dx/m/dx));
    end
%     绘制解析解的点，不要线,不显示DisplayName
    plot(y,U_plot,'-','DisplayName',['ANA:t=',num2str(kk*dt)],'LineWidth',1.5,'Color', ...
        clors(kk/floor(mstep/5)));
    legend('show','Location','northwest');
    hold on;
    xlabel('y');
    ylabel('velocity');
    xlim([0,m]);
    ylim([0,uo]);
end

% if mod(kk,floor(mstep/10))==0
%     figure(2)
%     %设置图的比例
%     set(gcf,'unit','centimeters','position',[0 0 10 10]);
%     x = 0:1:n;
%     y = 0:1:m;
%     [X, Y] = meshgrid(x,y);
%     gca = pcolor(X, Y, u');
%     %用rainbow
%     shading interp;
%     colormap(jet);
%     colorbar;
%     set(gca, 'LineStyle','none');
%     xlabel('x');
%     ylabel('y');
%     title(['ux at t = ',num2str(kk*dt)]);
% end
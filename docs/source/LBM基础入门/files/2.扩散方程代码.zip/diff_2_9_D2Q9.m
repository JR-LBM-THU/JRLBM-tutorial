%LBM- 2-D2Q9, diffusion equation, note that c2=1/3, w0=4/9, w1-w4, 1/9
% and w5-w8, 1/36
clear
Lx=50;Ly=50;
dx = 1;
dt = 0.5;
cc = dx/dt;
m = Lx/dx+1;
n = Ly/dx+1;
w = [1/9,1/9,1/9,1/9,1/36,1/36,1/36,1/36,4/9];
e = [[1,0];[0,1];[-1,0];[0,-1];[1,1];[-1,1];[-1,-1];[1,-1];[0,0]];
cs2=1/3;
T=zeros(m,n);x=zeros(m);
f = zeros(9, m, n);
Tm=zeros(m);
x(1)=0.0; y(1)=0.0;
for i=1:m-1
    x(i+1)=x(i)+dx;
end
alpha=0.1;
omega=1/(0.5+3*alpha*dt/(dx^2));
twall=1.0;

nstep=2000/dt;

% initial condition
for k = 1:9
    f(k, :, :) = w(k).*T;
end

for k1=1:nstep
    %Collision:
    for k = 1:9
        f(k, :, :) = (1-omega).*squeeze(f(k, :, :)) + omega.*w(k).*T;
    end

    % Streaming:
    for k = 1:9
        f(k,:,:) = circshift(squeeze(f(k,:,:)), e(k,:));
    end
    
    % bottom wall
    f([2,5,6], :, 1) = f([2,5,6], :, 2);

    % calculate T
    T = squeeze(sum(f, 1));

    % left wall, non-equilibrium 
    T(1,:) = twall;
    Feq=ones(9,2,n);
    for k=1:1:9
        Feq(k,1,:) = w(k).*T(1,:);
        Feq(k,2,:) = w(k).*T(2,:);
    end
    f(:,1,:)=Feq(:,1,:)+f(:,2,:)-Feq(:,2,:);
    % right wall, non-equilibrium
    T(m,:) = 0;
    Feq=ones(9,2,n);
    for k=1:1:9
        Feq(k,1,:) = w(k).*T(m,:);
        Feq(k,2,:) = w(k).*T(m-1,:);
    end
    f(:,m,:)=Feq(:,1,:)+f(:,m-1,:)-Feq(:,2,:);
    % top wall, non-equilibrium
    T(:,n) = 0;
    Feq=ones(9,m,2);
    for k=1:1:9
        Feq(k,:,1) = w(k).*T(:,n);
        Feq(k,:,2) = w(k).*T(:,n-1);
    end
    f(:,:,n)=Feq(:,:,1)+f(:,:,n-1)-Feq(:,:,2);

end
for i=1:n
    Tm(i)=T(i,(n-1)/2);
end
figure(1)
plot(x,Tm)
xlabel('X')
ylabel('T')
figure(2)
contour(T')
% title('Flux')
% xlabel('X')
% ylabel('Flux')
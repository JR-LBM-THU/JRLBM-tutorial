% Chapter 5, diffusion
% LBM- 1-D1Q3, diffusion equation
clear
L = 100;
m=101;
dx=L/(m-1);
dt = 1;
w=[1/6,1/6,4/6]';
e = [1,-1,0];
T=zeros(1,m)+0.0;
x=0:dx:L;
alpha=0.25;
omega=1/(3.*alpha*dt/dx^2+0.5);
tw_left=0.0;
tw_right=0.0;
S = 0.0001;
nstep=50000/dt;
f = w*T;
%Collision:
for k1=1:nstep
    % plot
    if k1*dt==500 || k1*dt==1000 || k1*dt==2500 || k1*dt==10000 || k1*dt==20000 || k1*dt==50000
        figure(1)
        % 使用颜色映射中的某一颜色，使用 k1 来映射颜色
        plot(x, T, 'DisplayName', ['Time = ', num2str(k1*dt)],...
            'LineWidth', 1.5)
        hold on
        legend('-DynamicLegend')
        title('Temperature')
        xlabel('X')
        ylabel('T')
        drawnow
        %FDM:
        flux_FDM=(T(1:m-1)-T(2:m))/dx;
        figure(2)
        plot(x(1:end-1)+dx/2,flux_FDM,'-', 'DisplayName', ...
            ['FDM - Time = ',num2str(k1*dt)],'LineWidth', 1.5);
        hold on
        title('Flux');
        xlabel('X');
        ylabel('Flux');
        legend('-DynamicLegend');
        drawnow

    end
    % collision
    f = (1-omega)*f + omega.*w*T + dt*w*S*ones(1,m);
    % Streaming:
    for i = 1:2
        f(i,:) = circshift(f(i,:), e(i));
    end
    %Boundary condition:
    f(1,1)=tw_left-f(2,1)-f(3,1);
    f(2,m)=tw_right-f(1,m)-f(3,m);

    % Macroscopic:
    T = sum(f,1);
end
% Chapter 5, diffusion
% LBM- 1-D1Q3, diffusion equation
clear
L = 100;
m=101;
dx=L/(m-1);
dt = 1;
w=[1/6,1/6,4/6]';
e = [1,-1,0];
T=zeros(1,m)+0.5;
x=0:dx:L;
alpha=linspace(0.1,1,m);
omega=1./(3.*alpha*dt/dx^2+0.5);
tw_left=1.0;
tw_right=0.0;
nstep=200000/dt;
f = w*T;
%Collision:
for k1=1:nstep
    % plot
    if k1*dt==1 || k1*dt==500 || k1*dt==2000 || k1*dt==5000 || k1*dt==10000 || k1*dt==200000
        figure(1)
        % 使用颜色映射中的某一颜色，使用 k1 来映射颜色
        plot(x, T, 'DisplayName', ['Time = ', num2str(k1*dt)],...
            'LineWidth', 1.5)
        hold on
        legend('-DynamicLegend')
        title('Temperature')
        xlabel('X')
        ylabel('T')
        drawnow
        %FDM:
        flux_FDM=(T(1:m-1)-T(2:m))./dx.*(alpha(1:m-1)+alpha(2:m))/2;
        figure(2)
        plot(x(1:end-1)+dx/2,flux_FDM,'-', 'DisplayName', ...
            ['FDM - Time = ',num2str(k1*dt)],'LineWidth', 1.5);
        hold on;
        title('$\alpha \frac{\partial T} {\partial x}$','Interpreter','latex');
        xlabel('X');
        ylabel('$\alpha \frac{\partial T} {\partial x}$','Interpreter','latex');
        legend('-DynamicLegend');
        drawnow
    end
    % collision
    f = ones(3,1)*(1-omega).*f + ones(3,1)*omega.*(w*T);
    % Streaming:
    for i = 1:2
        f(i,:) = circshift(f(i,:), e(i));
    end
    %Boundary condition:
    f(1,1)=tw_left-f(2,1)-f(3,1);
    f(2,m)=tw_right-f(1,m)-f(3,m);

    % Macroscopic:
    T = sum(f,1);
end
% Chapter 5
% LBM- 1-D, diffusion equation D1Q2
clear
m=101;
dx=1.0;
f1=zeros(m,1);f2=zeros(m,1); flux=zeros(m,1);
x=zeros(m,1);
x(1)=0.0;
for i=1:m-1
    x(i+1)=x(i)+dx;
end
alpha=0.25;
omega=1/(alpha+0.5);
twall=1.0;
nstep=2000;
T = sin(x/(m-1)*pi);
for i=1:m
    f1(i)=0.5*T(i);
    f2(i)=0.5*T(i);
end
% 预定义颜色映射
colors = jet(2000);
for k1=0:nstep
    if mod(k1,200)==0
        figure(1)
        % 使用颜色映射中的某一颜色，使用 k1 来映射颜色
        color_index = mod(k1, size(colors, 1)) + 1;
        plot(x, T, 'DisplayName', ['Time step = ', num2str(k1)], 'Color', colors(color_index, :), 'LineWidth', 1.5)
        hold on
        legend('-DynamicLegend')
        title('Temperature')
        xlabel('X')
        ylabel('T')
        drawnow
    end
    %Collision:
    for i=1:m
        feq=0.5*T(i);
        f1(i)=(1-omega)*f1(i)+omega*feq;
        f2(i)=(1-omega)*f2(i)+omega*feq;
    end
    % Streaming:
    f1 = circshift(f1, 1);
    f2 = circshift(f2, -1);
    %     % Streaming:
    %     for i=1:m-1
    %         f1(m-i+1)=f1(m-i);
    %         f2(i)=f2(i+1);
    %     end
    %     %Boundary condition:
    %     f1(1)=twall-f2(1);
    %     f1(m)=f1(m-1);
    %     f2(m)=f2(m-1);

    for j=1:m
        T(j)=f1(j)+f2(j);
    end
end
%Flux:
for k=1:m
    flux(k)=omega*(f1(k)-f2(k));
end
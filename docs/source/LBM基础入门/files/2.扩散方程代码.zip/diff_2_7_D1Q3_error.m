% Chapter 5, diffusion
% LBM- 1-D1Q3, diffusion equation
clear
L = 100;
m=101;
dx=L/(m-1);
dt = 1;
w=[1/6,1/6,4/6]';
e = [1,-1,0];
T=zeros(1,m)+0.0;
x=0:dx:L;
alpha=0.25;
omega=1/(3.*alpha*dt/dx^2+0.5);
tw_left=0.0;
tw_right=1.0;
nstep=5000/dt;
f = w*T;
%Collision:
for k1=1:nstep
    % collision
    f = (1-omega)*f + omega.*w*T;
    % Streaming:
    for i = 1:2
        f(i,:) = circshift(f(i,:), e(i));
    end
    %Boundary condition:
    f(1,1)=tw_left-f(2,1)-f(3,1);
    f(2,m)=tw_right-f(1,m)-f(3,m);

    % Macroscopic:
    T = sum(f,1);

    % plot
    if k1*dt==500 || k1*dt==1000 || k1*dt==2500 || k1*dt==5000
        figure(1)
        % 使用颜色映射中的某一颜色，使用 k1 来映射颜色
        plot(x, T, 'DisplayName', ['t = ', num2str(k1*dt)],...
            'LineWidth', 1.5)
        hold on
        T_ana=tw_right.*x/L.*ones(1,m);
        for N = 1:1:100
            T_ana=T_ana-2*tw_right/pi/N.*exp(-N^2*pi^2*alpha*k1*dt/L^2).*sin(N*pi*(1-x/L));
        end
        scatter(x,T_ana,'DisplayName',['ANA: t =',num2str(k1*dt)]);
        hold on;
        legend('-DynamicLegend')
        xlabel('x')
        ylabel('T')
        drawnow
    end
end

error = sqrt(sum((T-T_ana).^2)/m);
fprintf('The error for dx = %d is %.2e\n', dx, error);


% dx = [10,1,0.1];
% error = [1.81e-03,1.95e-05,1.96e-07];
% % 绘制误差随 dx 的变化在双对数坐标下的图像，并进行线性拟合
% figure(2)
% loglog(dx, error, 'o-', 'LineWidth', 1.5)
% hold on
% % 线性拟合
% p = polyfit(log(dx), log(error), 1);
% loglog(dx, exp(p(2))*dx.^p(1), 'r--', 'LineWidth', 1.5)
% xlabel('dx')
% ylabel('error')
% legend('error', ['fit: y = ', num2str(exp(p(2))), 'x^{', num2str(p(1)), '}'])
% title('Error vs dx')
% grid on

% Chapter 5
% LBM- 1-D, diffusion equation D1Q2
clear
L = 100;
m=101;
dx=L/(m-1);
dt = 1;
cc = dx/dt;
cs2 = cc^2;
T=ones(m,1)*0.0; f1=zeros(m,1); f2=zeros(m,1);
x=0:dx:L;
alpha=0.25;
omega=1/(alpha*dt/dx^2+0.5);
q_left=0.01;
T_right=0;
nstep=50000/dt;
for i=1:m
    f1(i)=0.5*T(i);
    f2(i)=0.5*T(i);
end
colors = jet(50000);
for k1=0:nstep
    if mod(k1*dt,10000)==0
        figure(1)
        % 使用颜色映射中的某一颜色，使用 k1 来映射颜色
        color_index = mod(k1*dt, size(colors, 1)) + 1;
        plot(x, T, 'DisplayName', ['Time = ', num2str(k1*dt)], 'Color', colors(color_index, :),...
            'LineWidth', 1.5)
        hold on
        legend('-DynamicLegend')
        title('Temperature')
        xlabel('X')
        ylabel('T')
        drawnow
        %Flux:
        flux_LBM=omega*(f1-f2)/dx;
        %FDM:
        flux_FDM=(T(1:m-1)-T(2:m))/dx;
        figure(2)
        plot(x,flux_LBM,'-', 'LineWidth', 2,'DisplayName', ...
                ['LBM - Time = ',num2str(k1*dt)], 'Color', colors(color_index, :) );
        hold on
        plot(x(1:end-1)+dx/2,flux_FDM,'o', 'DisplayName', ...
            ['FDM - Time = ',num2str(k1*dt)], 'Color', colors(color_index, :) );
        title('Flux');
        xlabel('X');
        ylabel('Flux');
        legend('-DynamicLegend');
        drawnow

    end
    %Collision:
    for i=1:m
        feq=0.5*T(i);
        f1(i)=(1-omega)*f1(i)+omega*feq;
        f2(i)=(1-omega)*f2(i)+omega*feq;
    end
    % Streaming:
    for i=1:m-1
        f1(m-i+1)=f1(m-i);
        f2(i)=f2(i+1);
    end
    %Boundary condition:
    f1(1)=f2(1)+q_left*dx/omega;
    f2(m)=T_right-f1(m);

    % macroscopic temperature
    for j=1:m
        T(j)=f1(j)+f2(j);
    end
end
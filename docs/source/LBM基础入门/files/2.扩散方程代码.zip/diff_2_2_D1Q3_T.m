% Chapter 5, diffusion
% LBM- 1-D1Q3, diffusion equation
clear
L = 100;
m=201;
dx=L/(m-1);
dt = 1;
w=[1/6,1/6,4/6]';
e = [1,-1,0];
T=zeros(1,m)+0.5;
x=0:dx:L;
alpha=0.25;
omega=1/(3.*alpha*dt/dx^2+0.5);
tw_left=1.0;
tw_right=0.0;
nstep=1000/dt;
f = w*T;
colors = jet(nstep);
%Collision:
for k1=1:nstep
    % plot
    if mod(k1,nstep/4)==0
        figure(1)
        % 使用颜色映射中的某一颜色，使用 k1 来映射颜色
        color_index = mod(k1, size(colors, 1)) + 1;
        plot(x, T, 'DisplayName', ['Time = ', num2str(k1*dt)], 'Color', colors(color_index, :),...
            'LineWidth', 1.5)
        hold on
        legend('-DynamicLegend')
        title('Temperature')
        xlabel('X')
        ylabel('T')
        drawnow
        %Flux:
        flux_LBM=3*omega*(f(1,:)-f(2,:))/dx;
        %FDM:
        flux_FDM=(T(1:m-1)-T(2:m))/dx;
        figure(2)
        plot(x,flux_LBM,'-', 'LineWidth', 2,'DisplayName', ...
                ['LBM - Time = ',num2str(k1*dt)], 'Color', colors(color_index, :) );
        hold on
        plot(x(1:end-1)+dx/2,flux_FDM,'o', 'DisplayName', ...
            ['FDM - Time = ',num2str(k1*dt)], 'Color', colors(color_index, :) );
        title('Flux');
        xlabel('X');
        ylabel('Flux');
        legend('-DynamicLegend');
        drawnow

    end
    % collision
    f = (1-omega)*f + omega.*w*T;
    % Streaming:
    for i = 1:2
        f(i,:) = circshift(f(i,:), e(i));
    end
    %Boundary condition:
    f(1,1)=tw_left-f(2,1)-f(3,1);
    f(2,m)=tw_right-f(1,m)-f(3,m);

    % Macroscopic:
    T = sum(f,1);
end
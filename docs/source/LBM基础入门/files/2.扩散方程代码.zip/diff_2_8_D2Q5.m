% LBM- 2-D2Q5a, diffusion equation, note that c2=1/3, w0=2/6, others 1/6
clear
Lx=50;Ly=50;
dx = 1;
dt = 1;
cc = dx/dt;
m = Lx/dx+1;
n = Ly/dx+1;
w = [1/6, 1/6, 1/6, 1/6, 2/6];
e = [[1,0];[0,1];[-1,0];[0,-1];[0,0]];
cs2=1/3;
T=zeros(m,n);x=zeros(m);
f = zeros(5, m, n);
Tm=zeros(m);
x(1)=0.0; y(1)=0.0;
for i=1:m-1
    x(i+1)=x(i)+dx;
end
alpha=0.1;
omega=1/(0.5+3*alpha*dt/(dx^2));
twall=1.0;


nstep=2000/dt;

% initial condition
for k = 1:5
    f(k, :, :) = w(k).*T;
end

%Collision:
for k1=1:nstep
    %Collision:
    for k = 1:5
        f(k, :, :) = (1-omega).*squeeze(f(k, :, :)) + omega.*w(k).*T;
    end

    % Streaming:
    for k = 1:4
        f(k,:,:) = circshift(squeeze(f(k,:,:)), e(k,:));
    end
    
    %Boundary condition:
    f(2,:,1) = f(2,:,2);
    f(1,1,:) = twall - (f(2,1,:) + f(3,1,:) + f(4,1,:) + f(5,1,:));
    f(3,m,:) = 0 - (f(1,m,:) + f(2,m,:) + f(4,m,:) + f(5,m,:));
    f(4,:,n) = 0 - (f(1,:,n) + f(2,:,n) + f(3,:,n) + f(5,:,n));
    
    % calculate T
    T = squeeze(sum(f, 1));

end

for i=1:n
    Tm(i)=T(i,(n-1)/2);
end
figure(1)
plot(x,Tm)
xlabel('X')
ylabel('T')
figure(2)
contour(T')
% title('Flux')
% xlabel('X')
% ylabel('Flux')
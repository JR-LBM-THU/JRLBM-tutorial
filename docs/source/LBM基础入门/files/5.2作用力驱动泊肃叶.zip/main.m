% 代码讲解见B站：JR同学教LBM-THU
% 文档见网站：https://jrlbm-tutorial.readthedocs.io/

% 此文件使用D2Q9求解泊肃叶流动，并将计算结果与理论结果进行了比较，
% 边界采用半反弹边界（相较于全反弹，所有的n+1换成了n）
% 作用力作为驱动力，不再需要施加压力边界，所有的m+1换成m
clear
clc
% 定义一些常量
dx = 1;
dt = dx^2;
cc = dx/dt;
cs2 = cc^2/3;
n=20/dx;
m=3/dx;
mstep=10000/dt;
rhoo = 1.00;
nu = 0.1;
tau = 3*dt*nu/dx^2 + 0.5;
omega = 1.0/tau;
% 定义变量
rho = ones(n,m)*rhoo;
f = zeros(9,n,m);
feq = zeros(9,n,m);
u = zeros(n,m);
v = zeros(n,m);
velocity = zeros(n,m);


%define the weight coefficient.
w=[1/9;1/9;1/9;1/9;1/36;1/36;1/36;1/36;4/9];
e = [1,0 ; 0,1 ; -1,0 ; 0,-1 ; 1,1 ; -1,1 ; -1,-1 ; 1,-1 ; 0,0]*cc;

Fx = 0;
Fy = 0.001/50;

% initialize the distribution function.
for k=1:1:9
    f(k,:,:)=feq_D2Q9(k,rho,u,v,w,e,cs2);
end

%main cycle
tic;
for kk=1:1:mstep
    % collision  主要修改的地方
    for k =1:1:9
        e_u = e(k,1)*u + e(k,2)*v;
        GF = w(k)*( ((e(k,1)-u)/cs2 + (e_u*e(k,1))/cs2/cs2).*Fx + ...
                            ( (e(k,2)-v)/cs2 + (e_u*e(k,2))/cs2/cs2 ).*Fy );
        feq(k,:,:)=feq_D2Q9(k,rho,u,v,w,e,cs2);
        f(k,:,:) = squeeze(omega * feq(k,:,:) + (1-omega)*f(k,:,:)) + dt*(1-0.5/tau).*GF;
    end

    f_old = f;% 修改的地方
    %streaming
    evolution

    %left boundary u=0,v=0 半反弹
    f(1,1,:) = f_old(3,1,:);
    f(5,1,:) = f_old(7,1,:);
    f(8,1,:) = f_old(6,1,:);
    %right boundary u=0,v=0 半反弹
    f(3,end,:) = f_old(1,end,:);
    f(7,end,:) = f_old(5,end,:);
    f(6,end,:) = f_old(8,end,:);

    % 计算宏观量
    rho = squeeze(sum(f,1));
    usum=zeros(n,m);
    vsum=zeros(n,m);
    for k=1:1:9
        usum = usum + squeeze(f(k,:,:)) * e(k,1);
        vsum = vsum + squeeze(f(k,:,:)) * e(k,2);
    end
    u = (usum + dt * Fx / 2) ./ rho; % 修改的地方
    v = (vsum + dt * Fy / 2) ./ rho; % 修改的地方

    % Move at y=m+1， 非平衡态边界条件 全部不需要

    plot_fig
end
toc;